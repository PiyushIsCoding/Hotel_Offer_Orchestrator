# Hotel Offer Orchestrator — tests for Phases 1 and 2

This bundle contains automated tests for the functionality reported as implemented:

- Phase 1: Express app and `GET /health`
- Phase 2: Supplier A/B endpoints, city validation, response shape, overlapping and supplier-exclusive hotel names

## 1. Install test dependencies

Run from your project root:

```powershell
npm install -D vitest supertest @types/supertest
```

## 2. Make the Express app importable

The tests import `../src/app`. If your current `src/server.ts` creates the Express app and calls `app.listen()` in the same file, split the app setup from the server startup:

- `src/app.ts`: create/configure Express, register `/health` and supplier routes, then `export default app`. Do not call `listen()` here.
- `src/server.ts`: load dotenv, import the app, and call `app.listen()`.

Example `src/server.ts`:

```ts
import dotenv from "dotenv";
import app from "./app";

dotenv.config();

const port = Number(process.env.PORT) || 3000;

app.listen(port, () => {
  console.log(`Hotel Offer Orchestrator running on port ${port}`);
});
```

In `src/app.ts`, keep your existing supplier route import and route mounting. The final paths must remain:
- `/supplierA/hotels`
- `/supplierB/hotels`

The exact import path depends on the route structure Copilot created, so do not blindly replace your existing route registration.

## 3. Add scripts to `package.json`

Merge these into your existing `scripts` object; preserve the other entries:

```json
"test": "vitest run",
"test:watch": "vitest",
"test:phase1": "vitest run tests/phase1.test.ts",
"test:phase2": "vitest run tests/phase2.test.ts"
```

## 4. Copy the `tests` folder

Copy this bundle's `tests` directory into the project root. It should sit alongside `src`, not inside it.

```text
Hotel Orchestrator/
├── src/
│   ├── app.ts
│   └── server.ts
├── tests/
│   ├── phase1.test.ts
│   └── phase2.test.ts
├── package.json
└── tsconfig.json
```

## 5. Run tests

```powershell
npm run test:phase1
npm run test:phase2
```

Run both together with:

```powershell
npm test
```

## Test assumptions

- `/health` returns JSON containing `status: "ok"`.
- Missing `city` returns HTTP 400.
- A supported city returns HTTP 200 and an array with at least one hotel.
- An unsupported city returns HTTP 200 and an empty array.
- Each hotel contains `name`, `price`, and `commissionPct`.
- Delhi has at least one overlapping hotel name and at least one supplier-exclusive name.
- Hotel names are compared after trimming whitespace and ignoring case.

The tests deliberately avoid fixed hotel names, prices, IDs, and record counts. If your current health response uses a different status field/value, or the route wiring differs, align the tests/app adapter with your actual implementation rather than changing the business behavior just to make a test pass.
